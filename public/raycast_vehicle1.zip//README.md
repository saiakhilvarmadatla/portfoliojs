# raycast-car-experiment
Created with CodeSandbox

Experimenting with React Three Fiber and React Three Cannon 

![car_test](https://user-images.githubusercontent.com/37863665/135091020-8a428493-8862-4884-8796-6e2b267138d6.gif)
